﻿var QuickFindView;
var searchContent;
var _fetchxml;
var entityType;
var _oService;
var _sOrgName = "";
function initSearch() {
   // debugger;
    searchContent = document.getElementById("searchtxt").value;
    if (searchContent == "") {
        alert("Specify the value")
        return;
    }

     entityType = $('#entityType')[0].options[$('#entityType')[0].selectedIndex].value;
    switch (entityType) {
        case "Account":
            QuickFindView = "Quick Find Active Accounts";
            break;
        case "Contact":
            QuickFindView = "Quick Find Active Contacts";
            break;
    }
    if (QuickFindView == undefined || QuickFindView == "") {
        alert("Quick Find view not found")
        return;
    }
    Getfetchxml(QuickFindView);
}
function retrieveentityCollection(entity, options) {
    var serverURL = window.parent.Xrm.Page.context.getClientUrl();
    var Query = entity + options;
    var req = new XMLHttpRequest();
    req.open("GET", serverURL + "/api/data/v8.2/" + Query, false);
    req.setRequestHeader("Accept", "application/json");
    req.setRequestHeader("Content-Type", "application/json; charset=utf-8");
    req.setRequestHeader("OData-MaxVersion", "4.0");
    req.setRequestHeader("OData-Version", "4.0");
    req.onreadystatechange = function () {
        if (this.readyState == 4 /* complete */) {
            req.onreadystatechange = null;
            if (this.status == 200) {
              //  debugger;
                var data = JSON.parse(this.response);
                if (data['@odata.context'] != null && data.value.length > 0) {
                    _fetchxml = data.value[0].fetchxml;
                }
            }
            else {
                var error = JSON.parse(this.response).error;
                alert(error.message);
            }
        }

    };
    req.send();
    return _fetchxml;
}
function Getfetchxml(QuickFindView) {
    var _entity = "savedqueries";
    var _columnSet = "?$select=fetchxml&$filter=(name eq '" + QuickFindView + "') and (isquickfindquery eq true)";
   retrieveentityCollection(_entity, _columnSet);
   if (_fetchxml != undefined) {
       _fetchxml = _fetchxml.split('{0}').join('%'+searchContent+'%');
       retrieveDatabyFetch(_fetchxml);
   }
   else
       alert("Query not found");
}

function retrieveDatabyFetch(fetchXml)
{
   // debugger;
    var serverUrl = window.parent.Xrm.Page.context.getClientUrl();
    _oService = new FetchUtil(_sOrgName, serverUrl);
    var results = _oService.Fetch(fetchXml);
    if (results.length > 0) {
        readRecordsOnSuccess(results);
      //  setMAP(results);
    }
}



function readRecordsOnSuccess(data) {
    var mapdiv = document.getElementById("mapdiv");
    var myOptions = {
        zoom: 4,
        center: new google.maps.LatLng(-34.397, 150.644),
        mapTypeId: google.maps.MapTypeId.ROADMAP
    }
    var mapObject = new google.maps.Map(mapdiv, myOptions);
    var geocoder = new google.maps.Geocoder();

  //  debugger;
    //Create a table and header using the DOM
    //var oTable = document.createElement("table");
    var outdivId = document.getElementById("lstdiv");
    var oTable = document.getElementById("configGrid");

    if (oTable != null) {
        oTable.innerHTML = "";
        var oTBody = document.createElement("tbody");
        var row = document.createElement("tr");
        // Loop through the retrieved records
        for (var indx = 0; indx < data.length; indx++) {
            if (data[indx].attributes.accountid != null)
            {

                var odiv = document.createElement("div");

                var oTRow = document.createElement("tr");
                var oTRowTD = document.createElement("td");
                var oTRowA = document.createElement("a");
                sethyperlink(oTRowA, data[indx].attributes.name.value, data[indx].attributes.accountid.value, 1);
                odiv.appendChild(oTRow);
                oTRow.appendChild(oTRowTD);
                oTRowTD.appendChild(oTRowA);

                if (data[indx].attributes.address1_composite != undefined) {
                    var oTRowAdd = document.createElement("tr");
                    var oTRowTDAdd = document.createElement("td");
                    setText(oTRowTDAdd, data[indx].attributes.address1_composite.value);
                    odiv.appendChild(oTRowAdd);
                    oTRowAdd.appendChild(oTRowTDAdd);
                }
                oTBody.appendChild(odiv);
            }

            if (data[indx].attributes.contactid != null)
            {
                var odiv = document.createElement("div");

                var oTRow = document.createElement("tr");
                var oTRowTD = document.createElement("td");
                var oTRowA = document.createElement("a");
                sethyperlink(oTRowA, data[indx].attributes.fullname.value, data[indx].attributes.contactid.value, 2);
                odiv.appendChild(oTRow);
                oTRow.appendChild(oTRowTD);
                oTRowTD.appendChild(oTRowA);
                if (data[indx].attributes.address1_composite != undefined) {
                    var oTRowAdd = document.createElement("tr");
                    var oTRowTDAdd = document.createElement("td");
                    setText(oTRowTDAdd, data[indx].attributes.address1_composite.value);
                    odiv.appendChild(oTRowAdd);
                    oTRowAdd.appendChild(oTRowTDAdd);
                }
                oTBody.appendChild(odiv);
            }
            if (data[indx].attributes.address1_composite != null) {
                var title;
                if (entityType == "Account")
                    title = data[indx].attributes.name.value;
                if (entityType == "Contact")
                    title = data[indx].attributes.fullname.value;
                // Place the marker 
                var address = data[indx].attributes.address1_composite.value;
                geocoder.geocode(
                    { 'address': address },
                    function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            mapObject.setCenter(results[0].geometry.location);
                            mapObject.setZoom(14);
                            var marker = new google.maps.Marker({
                                map: mapObject,
                                position: results[0].geometry.location,
                                title: results[0].formatted_address
                            });
                        } else {
                            //alert("Geocode was not successful for the following reason: " + status);
                        }
                    });
            }
        }
        oTable.appendChild(oTBody);
        outdivId.appendChild(oTable);
    }
}
function setText(element, text) {
    if (typeof element.innerText != "undefined") {
        element.innerText = text;
        
    }
    else { element.textContent = text; }
}
function sethyperlink(element, text,id,type) {
    if (typeof element.innerText != "undefined") {
        element.innerText = text;
        element.href = window.parent.Xrm.Page.context.getClientUrl() +
            "/main.aspx?etc=" + type + "&id=%7b" + id + "%7d&newWindow=true&pagetype=entityrecord";
        element.target = "_blank";
    }
    else {
        element.textContent = text;
        element.href = window.parent.Xrm.Page.context.getClientUrl() +
            "/main.aspx?etc=" + type + "&id=%7b" + id + "%7d&newWindow=true&pagetype=entityrecord";
        element.target = "_blank";
    }
}

//function setMAP(data)
//{
//    debugger;
//    var mapdiv = document.getElementById("mapdiv");
//    var myOptions = { 
//        zoom: 4, 
//        center: new google.maps.LatLng(-34.397, 150.644),
//        mapTypeId: google.maps.MapTypeId.ROADMAP 
//    }
//    var mapObject = new google.maps.Map(mapdiv, myOptions); 
//    var geocoder = new google.maps.Geocoder();

//    for (var indx = 0; indx < data.length; indx++) {
//        if (data[indx].attributes.address1_composite != null )
//        {
//            var title;
//                if (entityType == "Account")
//                    title= data[indx].attributes.name.value;
//                if (entityType == "Contact")
//                    title= data[indx].attributes.fullname.value;
//            // Place the marker 
//            var address = data[indx].attributes.address1_composite.value;
//            geocoder.geocode(
//                { 'address': address },
//                function (results, status) {
//                if (status == google.maps.GeocoderStatus.OK) {
//                    mapObject.setCenter(results[0].geometry.location);
//                    mapObject.setZoom(14);
//                    var marker = new google.maps.Marker({
//                        map: mapObject,
//                        position: results[0].geometry.location,
//                        title: title
//                    });
//                } else {
//                    //alert("Geocode was not successful for the following reason: " + status);
//                }
//            });
//        }
//    }

//}


